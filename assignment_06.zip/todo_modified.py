#-------------------------------------------------#
# Title: Working functions and classes
# Student:   Tri Nguyen
# Instructor: Randal Root
# Date:  02-Nov-2017
#-------------------------------------------------#

# -- DATA CODE --
# Declare dictionaries, lists to store data
dicRow = {}
lstTable = []
start_list = []
dicRow_one = {}
dicRow_two = {}

# --PROCESSING CODE--
# create a text file named Todo.txt and write 2 lines of data
todo_list = open('Todo.txt', 'w')
todo_list.write('Clean House, low' + '\n')
todo_list.write('Pay Bills, high' + '\n')
todo_list.close() # close Todo.txt after done writing to it

# Open Todo.txt to read
todo_list_read = open('Todo.txt')
list_of_lines = todo_list_read.readlines() # list_of_lines contains a list of 2 lines writen to Todo.txt

# start_list is a list that contains 2 lines of data in Todo.txt
# list_of_lines[0] is "Clean House, low"
# list_of_lines[1] is "Pay Bills, high"
start_list.append(list_of_lines[0].rstrip())
start_list.append(list_of_lines[1].rstrip())

# start_list[0].split(',') will split "Clean House, low" into ["Clean House", "low"]
# start_list[1].split(',') will split "Pay Bills, high" into ["Pay Bills", "high"]
# then the data is stored in 2 lists respectively, first_list and second_list
first_list = start_list[0].split(',')
second_list = start_list[1].split(',')

# Store the 2 lines to 2 respective dictionaries, dicRow_one and dicRow_two
dicRow_one = {'Task':first_list[0], 'Priority':first_list[1]}
dicRow_two = {'Task':second_list[0], 'Priority':second_list[1]}
todo_list_read.close()

# append dicRow_one and dicRow_two to lstTable list
lstTable = [dicRow_one, dicRow_two]

# create a Class called ToDo

class Todo(object):
	''' This class contains methods of the todo list script '''
	
	# define methods
	@staticmethod
	def display_menu():
		''' this function will display the menu of options to the user '''
		menu = '''Menu of Options
		1) Show current data
		2) Add a new item
		3) Remove an existing item
		4) Save Data to a File
		5) Exit Program'''
		return menu
	
	@staticmethod
	def process_input(input_one, input_two):
		''' this function will process 2 inputs, string of input_one will be converted to title(),
			string of input_two will be converted to lowercase by lower()
		'''
		first_input = input(input_one).title()
		second_input = input(input_two).lower()
		
		input_list = [first_input, second_input]
		return input_list
		
	@staticmethod
	def display_current_data(data):
		''' this function display the current data of the todo list '''
		
		for indx, item in enumerate(data):
			print('{} - {}'.format(indx + 1, item))
		
	@staticmethod
	def save_to_text_file(name_of_file, data_to_store):
		''' this function saves data to a text file, the user provide the name_of_file and data_to_store '''
		
		store_to_file = open(name_of_file, 'w')
		for indx, item in enumerate(data_to_store):
			data = str(data_to_store[indx]['Task']) + ', ' + str(data_to_store[indx]['Priority'])
			store_to_file.write(data + '\n')
		store_to_file.close()
		

# --PRESENTATION (I/0) CODE--

while True:
	# Display a menu of choices to the user
	
	print(Todo.display_menu())
	print() # add a new line for formatting purposes
	
	strChoice = str(input('Which option would you like to perform? [1 to 4] - '))
	print() #adding a new line
	
	# if option #1 is selected, print out the current list
	if strChoice.strip() == '1':
		print('You have selected option #1 to show current data:')
		Todo.display_current_data(lstTable)
		print() # add new line
		continue
		
	# if option #2 is selected, allow the user to add a task
	elif strChoice.strip() == '2':
		lst_of_inputs = Todo.process_input('Enter a task: ', 'Enter a priority [low, medium, high:] ')
		task = lst_of_inputs[0]
		priority = lst_of_inputs[1]
		print() # adding a new line
		print('You have added task - {} -> priority is {}'.format(task, priority))
		dicRow = {'Task':task, 'Priority':priority} # add new task and priority to a dictionary
		lstTable.append(dicRow) # append dicRow to the lstTable list
		print() # add new line
		continue
		
	# If option #3 is selected, remove an item from the list/Table
	elif strChoice.strip() == '3':
		print('You have selected option #3 to remove an item from the list.')
		print() # add new line
		Todo.display_current_data(lstTable)
		print() # add new line
		to_be_removed = input('What task would you like to remove from the list above? ')
		print() # add new line
		for indx, item in enumerate(lstTable):
			if to_be_removed.strip().title() in lstTable[indx]['Task']:
				lstTable.remove(item)
		print('task removed!')
		print() # add new line
		print('Current list:')
		Todo.display_current_data(lstTable)
		print() # add new line
		continue
		
	# Step 6 - Save tasks to the Todo.txt file
	elif strChoice.strip() == '4':
		print('You have selected to save tasks to the Todo.txt file.')
		Todo.save_to_text_file('Todo.txt', lstTable)
		print('Tasks have been saved to Todo.txt file!!')
		print() # add new line
		continue
		
	elif strChoice.strip() == '5':
		break # and Exit the program